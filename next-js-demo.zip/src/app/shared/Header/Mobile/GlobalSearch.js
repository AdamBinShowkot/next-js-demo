import React from 'react';

const GlobalSearch=()=>{
    return(
        <>
        </>
    )
}
export default GlobalSearch;
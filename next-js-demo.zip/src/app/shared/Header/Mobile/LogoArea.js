import React from 'react';

const LogoArea=()=>{
    return(
        <>
        </>
    )
}
export default LogoArea;
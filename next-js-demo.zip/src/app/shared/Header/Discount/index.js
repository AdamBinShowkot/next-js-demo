import React from 'react';
import Col from 'react-bootstrap/Col';
import './index.scss'


const DiscountMain=()=>{
    return(
        <>
            <Col
            className='discount-content'
            >
                <h3>Invite Friends and get 50% off on your next purchase.</h3>
            </Col>
        </>
    )
}
export default DiscountMain;
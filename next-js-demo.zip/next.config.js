// const withPlugins = require("next-compose-plugins");
// const withImages = require("next-images");
// module.exports = withPlugins([], {});
// module.exports = withImages();


// /** @type {import('next').NextConfig} */
const nextConfig = {}

module.exports = nextConfig